# 🚀 Guia de Deploy - Jarvis AI Assistant

Este documento descreve como fazer o deploy do Jarvis em diferentes plataformas.

## ⚡ Deploy Rápido com Vercel (Recomendado)

### Pré-requisitos
- Conta no Vercel (gratuita)
- Repositório GitHub com o código do Jarvis
- Chave de API OpenAI

### Passos

1. Faça login no Vercel: https://vercel.com/login
2. Clique em "New Project"
3. Selecione "Import Git Repository"
4. Cole a URL do seu repositório GitHub
5. Configure as variáveis de ambiente:
   - OPENAI_API_KEY
   - JWT_SECRET
   - NODE_ENV=production
6. Clique em "Deploy"

### URL do Site
Após deploy: https://seu-projeto.vercel.app

---

## 🌐 Deploy com Netlify

1. Vá para https://netlify.com
2. Clique em "New site from Git"
3. Conecte seu repositório GitHub
4. Configure:
   - Build command: pnpm build
   - Publish directory: dist/public
5. Adicione variáveis de ambiente
6. Deploy automático!

---

## 🔐 Variáveis de Ambiente

OPENAI_API_KEY=sk-your-key
JWT_SECRET=seu-secret-aleatorio
NODE_ENV=production

---

Mais informações em README.md
