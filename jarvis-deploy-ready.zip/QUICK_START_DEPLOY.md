# 🚀 Guia Rápido de Deploy - Jarvis AI

## Opção 1: Deploy em 2 Minutos com Vercel ⚡

### Passo 1: Preparar o Repositório
```bash
git clone seu-repositorio
cd jarvis-project
git push origin main
```

### Passo 2: Deploy no Vercel
1. Acesse https://vercel.com
2. Clique em "New Project"
3. Selecione seu repositório GitHub
4. Clique em "Import"

### Passo 3: Configurar Variáveis
Na página de configuração, adicione:
- `OPENAI_API_KEY`: Sua chave OpenAI (https://platform.openai.com/api-keys)
- `JWT_SECRET`: Qualquer string aleatória
- `NODE_ENV`: `production`

### Passo 4: Deploy!
Clique em "Deploy" e aguarde 2-3 minutos.

**Seu site estará em:** `https://seu-projeto.vercel.app`

---

## Opção 2: Deploy com Netlify 🌐

1. Acesse https://netlify.com
2. Clique em "New site from Git"
3. Conecte seu repositório GitHub
4. Build command: `pnpm build`
5. Publish directory: `dist/public`
6. Adicione as mesmas variáveis de ambiente
7. Clique em "Deploy"

---

## Opção 3: Deploy Local (Teste Primeiro)

```bash
# Instalar dependências
pnpm install

# Configurar variáveis
cp .env.example .env
# Edite .env e adicione OPENAI_API_KEY

# Build
pnpm build

# Iniciar servidor
pnpm start
```

Acesse em: http://localhost:3000/jarvis

---

## 📋 Checklist Antes de Deploy

- [ ] Você tem uma chave OpenAI válida?
- [ ] Seu repositório está no GitHub?
- [ ] Você tem conta em Vercel ou Netlify?
- [ ] As variáveis de ambiente estão configuradas?

---

## 🆘 Problemas Comuns

### "Cannot find module 'openai'"
```bash
pnpm install openai
```

### "OPENAI_API_KEY not configured"
Verifique se a variável está no Vercel/Netlify Environment Variables

### Erro de build
Verifique o log de build na plataforma (Vercel/Netlify dashboard)

---

## 📞 Próximos Passos

1. Seu site está no ar! 🎉
2. Teste a funcionalidade em `/jarvis`
3. Configure um domínio personalizado (opcional)
4. Configure SSL/HTTPS (automático em Vercel/Netlify)

---

**Pronto! Seu Jarvis está online!** 🤖
