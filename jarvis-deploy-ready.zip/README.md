# Jarvis - Advanced AI Assistant with 3D Animated Sphere

Um assistente de IA avançado baseado no Jarvis do Homem de Ferro, com interface 3D imersiva, suporte multilíngue e síntese de voz profissional.

## 🌟 Características

- **Esfera Holográfica Animada**: Visualização 3D em tempo real usando Three.js
- **Voz do Jarvis**: Síntese de voz profissional usando OpenAI TTS
- **Multilíngue**: Detecta e responde em qualquer idioma
- **Modos de Resposta**: Texto, Áudio ou Ambos
- **Interface Futurista**: Design moderno com tema escuro
- **Chat em Tempo Real**: Comunicação fluida com a IA

## 🚀 Quick Start

### Pré-requisitos
- Node.js 18+
- pnpm 10+
- Chave de API OpenAI

### Instalação Local

1. Clone ou extraia o projeto:
```bash
unzip jarvis-final.zip
cd jarvis-project
```

2. Instale as dependências:
```bash
pnpm install
```

3. Configure as variáveis de ambiente:
```bash
cp .env.example .env
# Edite .env e adicione sua OPENAI_API_KEY
```

4. Inicie o servidor de desenvolvimento:
```bash
pnpm dev
```

5. Acesse em seu navegador:
```
http://localhost:3000/jarvis
```

## 📦 Build para Produção

```bash
pnpm build
pnpm start
```

## 🌐 Deploy

### Opção 1: Vercel (Recomendado)

1. Faça login no [Vercel](https://vercel.com)
2. Clique em "New Project"
3. Importe o repositório Git
4. Configure as variáveis de ambiente:
   - `OPENAI_API_KEY`
   - `BUILT_IN_FORGE_API_KEY`
   - `JWT_SECRET`
5. Clique em "Deploy"

### Opção 2: Netlify

1. Faça login no [Netlify](https://netlify.com)
2. Clique em "New site from Git"
3. Selecione o repositório
4. Configure as variáveis de ambiente
5. Clique em "Deploy site"

### Opção 3: Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN pnpm install
RUN pnpm build
EXPOSE 3000
CMD ["pnpm", "start"]
```

## 🔧 Estrutura do Projeto

```
jarvis-project/
├── client/                 # Frontend React + Vite
│   ├── src/
│   │   ├── components/    # Componentes React
│   │   ├── pages/         # Páginas da aplicação
│   │   └── App.tsx        # Componente raiz
│   └── index.html         # HTML principal
├── server/                # Backend Express + tRPC
│   ├── routers/           # Rotas da API
│   │   ├── chat.ts        # Router de chat
│   │   └── voice.ts       # Router de síntese de voz
│   └── _core/             # Configurações centrais
├── shared/                # Código compartilhado
└── package.json           # Dependências do projeto
```

## 🎨 Componentes Principais

### JarvisComplete
Componente principal que integra:
- Chat interativo
- Esfera 3D animada
- Síntese de voz
- Seleção de modos de resposta

### JarvisAnimatedSphere
Componente 3D que renderiza:
- Esfera holográfica azul
- Partículas dinâmicas
- Efeitos de brilho
- Animações sincronizadas com áudio

## 🔐 Variáveis de Ambiente

```env
OPENAI_API_KEY=sk-...              # Chave da API OpenAI
BUILT_IN_FORGE_API_KEY=...         # Chave da API Forge (LLM)
JWT_SECRET=seu_secret_aqui         # Secret para JWT
NODE_ENV=production                # Ambiente
```

## 📝 API Endpoints

### Chat
- `POST /api/trpc/chat.sendMessage` - Enviar mensagem
- `GET /api/trpc/chat.getHistory` - Obter histórico

### Voice
- `POST /api/trpc/voice.synthesize` - Sintetizar fala
- `GET /api/trpc/voice.getVoices` - Listar vozes disponíveis

## 🎯 Uso

1. Acesse a interface do Jarvis
2. Escolha o modo de resposta (Texto, Áudio ou Ambos)
3. Selecione a voz desejada
4. Digite sua mensagem ou use o reconhecimento de voz
5. O Jarvis responderá com a esfera animada sincronizada

## 🌍 Idiomas Suportados

- Português (PT/BR)
- English (EN)
- Español (ES)
- Français (FR)
- Deutsch (DE)
- Italiano (IT)
- 日本語 (JA)
- 中文 (ZH)
- E muitos outros!

## 📞 Suporte

Para questões ou problemas, consulte a documentação oficial ou abra uma issue no repositório.

## 📄 Licença

MIT License - Veja LICENSE para detalhes

---

**Desenvolvido com ❤️ para uma experiência de IA imersiva**
