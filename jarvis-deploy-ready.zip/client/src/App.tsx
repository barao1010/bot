import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import JarvisWidget from "./pages/JarvisWidget";
import JarvisPage from "./pages/JarvisPage";
import Infinito from "./pages/Infinito";
import InfinitoApp from "./pages/InfinitoApp";
import InfinitoSimplePage from "./pages/InfinitoSimplePage";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="" component={Home} />
      <Route path="/widget" component={JarvisWidget} />
      <Route path="/jarvis" component={JarvisPage} />
      <Route path="/infinito" component={Infinito} />
      <Route path="/app" component={InfinitoApp} />
      <Route path="/simple" component={InfinitoSimplePage} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook
function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
