import { useState, useRef, useEffect } from 'react';
import { Mic, X, MessageCircle, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HolographicSphereProps {
  onClose?: () => void;
  isListening?: boolean;
  isResponding?: boolean;
}

export default function HolographicSphere({
  onClose,
  isListening = false,
  isResponding = false,
}: HolographicSphereProps) {
  const sphereRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isExpanded, setIsExpanded] = useState(false);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('[data-no-drag]')) return;
    
    setIsDragging(true);
    const rect = sphereRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      
      // Keep within viewport
      const maxX = window.innerWidth - 120;
      const maxY = window.innerHeight - 120;
      
      setPosition({
        x: Math.max(0, Math.min(newX, maxX)),
        y: Math.max(0, Math.min(newY, maxY)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  return (
    <div
      ref={sphereRef}
      className="fixed z-50 select-none"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        cursor: isDragging ? 'grabbing' : 'grab',
      }}
      onMouseDown={handleMouseDown}
    >
      {/* Outer glow layers */}
      <div className="absolute inset-0 w-32 h-32 rounded-full bg-gradient-to-br from-cyan-500/20 to-transparent blur-2xl animate-pulse" />
      <div className="absolute inset-2 w-28 h-28 rounded-full bg-gradient-to-br from-orange-500/10 to-transparent blur-xl" />

      {/* Main holographic sphere */}
      <div
        className={`relative w-32 h-32 rounded-full overflow-hidden transition-all duration-300 ${
          isExpanded ? 'scale-110' : 'scale-100'
        }`}
      >
        {/* Sphere background with gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 via-blue-600/40 to-orange-500/20 rounded-full" />

        {/* Inner glow */}
        <div className="absolute inset-0 bg-gradient-to-t from-transparent via-white/5 to-cyan-400/10 rounded-full" />

        {/* Animated scan lines */}
        <div className="absolute inset-0 rounded-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-400/10 to-transparent animate-pulse" />
          {isResponding && (
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-orange-400/20 to-transparent animate-pulse" style={{ animationDuration: '1.5s' }} />
          )}
        </div>

        {/* Rotating rings */}
        <div className="absolute inset-0 rounded-full border-2 border-cyan-400/30 animate-spin" style={{ animationDuration: '8s' }} />
        <div className="absolute inset-1 rounded-full border border-orange-400/20 animate-spin" style={{ animationDuration: '-6s' }} />

        {/* Center icon/content */}
        <div className="absolute inset-0 flex items-center justify-center">
          {isListening ? (
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 bg-orange-500/40 rounded-full animate-pulse" />
              <div className="absolute inset-2 bg-orange-500/60 rounded-full" />
              <Mic className="absolute inset-3 w-6 h-6 text-white animate-pulse" />
            </div>
          ) : isResponding ? (
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 bg-cyan-500/40 rounded-full animate-pulse" />
              <div className="absolute inset-2 bg-cyan-500/60 rounded-full" />
              <MessageCircle className="absolute inset-3 w-6 h-6 text-white animate-pulse" style={{ animationDuration: '1.5s' }} />
            </div>
          ) : (
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 to-orange-500/20 rounded-full" />
              <div className="absolute inset-2 bg-gradient-to-br from-cyan-400/40 to-orange-400/20 rounded-full" />
              <div className="absolute inset-3 w-6 h-6 rounded-full bg-gradient-to-br from-cyan-300 to-cyan-500 flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full" />
              </div>
            </div>
          )}
        </div>

        {/* Reflection effect */}
        <div className="absolute top-2 left-2 w-8 h-8 bg-white/20 rounded-full blur-sm" />
      </div>

      {/* Floating action buttons (when expanded) */}
      {isExpanded && (
        <div
          className="absolute top-0 left-40 space-y-2 animate-fade-in"
          data-no-drag="true"
        >
          <Button
            size="icon"
            className="rounded-full bg-cyan-500/50 hover:bg-cyan-500/70 border border-cyan-400/50 h-10 w-10"
            title="Falar com Jarvis"
          >
            <Mic className="w-5 h-5" />
          </Button>
          <Button
            size="icon"
            className="rounded-full bg-orange-500/50 hover:bg-orange-500/70 border border-orange-400/50 h-10 w-10"
            title="Ativar síntese de fala"
          >
            <Volume2 className="w-5 h-5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="rounded-full border border-red-500/50 hover:bg-red-500/20 h-10 w-10"
            onClick={onClose}
            title="Fechar"
            data-no-drag="true"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
      )}

      {/* Tap to expand/collapse */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="absolute inset-0 rounded-full cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
        title="Expandir menu"
      />
    </div>
  );
}
