import { useState, useRef, useEffect } from 'react';
import { Mic, X, MessageCircle } from 'lucide-react';

interface InfinitoAvatarProps {
  onClose?: () => void;
  isListening?: boolean;
  isResponding?: boolean;
  onMicClick?: () => void;
}

export default function InfinitoAvatar({
  onClose,
  isListening = false,
  isResponding = false,
  onMicClick,
}: InfinitoAvatarProps) {
  const avatarRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: window.innerWidth - 120, y: window.innerHeight - 120 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [showMenu, setShowMenu] = useState(false);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('[data-no-drag]')) return;
    
    setIsDragging(true);
    const rect = avatarRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      
      // Keep within viewport
      const maxX = window.innerWidth - 100;
      const maxY = window.innerHeight - 100;
      
      setPosition({
        x: Math.max(0, Math.min(newX, maxX)),
        y: Math.max(0, Math.min(newY, maxY)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  return (
    <div
      ref={avatarRef}
      className="fixed z-50 select-none"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        cursor: isDragging ? 'grabbing' : 'grab',
      }}
      onMouseDown={handleMouseDown}
    >
      {/* Subtle glow */}
      <div className="absolute inset-0 w-24 h-24 rounded-full bg-gradient-to-br from-blue-500/10 to-transparent blur-xl" />

      {/* Main avatar circle */}
      <div
        className={`relative w-24 h-24 rounded-full overflow-hidden transition-all duration-300 ${
          isListening || isResponding ? 'scale-110' : 'scale-100'
        }`}
      >
        {/* Minimalist background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 to-slate-800 rounded-full" />

        {/* Subtle border */}
        <div className="absolute inset-0 rounded-full border border-slate-700/50" />

        {/* Animated pulse ring when listening */}
        {isListening && (
          <div className="absolute inset-0 rounded-full border-2 border-blue-500/50 animate-pulse" />
        )}

        {/* Animated response ring */}
        {isResponding && (
          <div className="absolute inset-0 rounded-full border-2 border-blue-400/30 animate-spin" style={{ animationDuration: '3s' }} />
        )}

        {/* Center content */}
        <div className="absolute inset-0 flex items-center justify-center">
          {isListening ? (
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-pulse" />
              <Mic className="absolute inset-2 w-6 h-6 text-blue-400 animate-pulse" />
            </div>
          ) : isResponding ? (
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 bg-blue-500/20 rounded-full" />
              <div className="absolute inset-2 flex items-center justify-center gap-1">
                <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
            </div>
          ) : (
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 to-blue-600/20 rounded-full" />
              <div className="absolute inset-2 w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-500 flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full" />
              </div>
            </div>
          )}
        </div>

        {/* Subtle reflection */}
        <div className="absolute top-2 left-2 w-4 h-4 bg-white/10 rounded-full blur-sm" />
      </div>

      {/* Floating menu */}
      {showMenu && (
        <div
          className="absolute top-0 left-32 space-y-2 animate-fade-in-scale"
          data-no-drag="true"
        >
          <button
            onClick={onMicClick}
            className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-800 border border-slate-700 hover:border-blue-500/50 transition-colors"
            title="Falar"
          >
            <Mic className="w-5 h-5 text-blue-400" />
          </button>
          <button
            onClick={() => setShowMenu(false)}
            className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-800 border border-slate-700 hover:border-red-500/50 transition-colors"
            title="Fechar menu"
            data-no-drag="true"
          >
            <X className="w-5 h-5 text-red-400" />
          </button>
        </div>
      )}

      {/* Click area */}
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="absolute inset-0 rounded-full cursor-pointer focus:outline-none"
        title="Menu"
      />
    </div>
  );
}
