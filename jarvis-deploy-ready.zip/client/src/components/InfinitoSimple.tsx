import { useState, useRef, useEffect } from 'react';
import { useVoiceRecognition } from '@/hooks/useVoiceRecognition';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { trpc } from '@/lib/trpc';

export default function InfinitoSimple() {
  const [position, setPosition] = useState({ x: window.innerWidth - 120, y: window.innerHeight - 120 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const sphereRef = useRef<HTMLDivElement>(null);
  const [isResponding, setIsResponding] = useState(false);
  const [conversationId, setConversationId] = useState<number | null>(null);

  const { isSpeaking, speak, stop: stopSpeech } = useTextToSpeech({
    rate: 0.95,
    pitch: 1,
    volume: 1,
    lang: 'pt-BR',
  });

  const { isListening, toggleListening } = useVoiceRecognition({
    language: 'pt-BR',
    onTranscript: (text) => {
      handleMessage(text);
    },
  });

  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const createConversationMutation = trpc.chat.createConversation.useMutation();

  // Initialize conversation on mount
  useEffect(() => {
    const initConversation = async () => {
      try {
        const conv = await createConversationMutation.mutateAsync({
          title: 'Infinito Chat',
        });
        setConversationId(conv.id);
      } catch (error) {
        console.error('Failed to create conversation:', error);
      }
    };

    initConversation();
  }, []);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    const rect = sphereRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      const maxX = window.innerWidth - 100;
      const maxY = window.innerHeight - 100;

      setPosition({
        x: Math.max(0, Math.min(newX, maxX)),
        y: Math.max(0, Math.min(newY, maxY)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  const handleMessage = async (text: string) => {
    if (!conversationId || !text.trim()) return;

    setIsResponding(true);

    try {
      const response = await sendMessageMutation.mutateAsync({
        conversationId,
        content: text,
      });

      // Speak the response
      speak(response.content);
    } catch (error) {
      console.error('Error sending message:', error);
      speak('Desculpe, ocorreu um erro ao processar sua solicitação.');
    } finally {
      setIsResponding(false);
    }
  };

  // Auto-start listening on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      toggleListening();
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {/* Sphere */}
      <div
        ref={sphereRef}
        className="fixed pointer-events-auto select-none"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          cursor: isDragging ? 'grabbing' : 'grab',
        }}
        onMouseDown={handleMouseDown}
      >
        {/* Glow effect */}
        <div className="absolute inset-0 w-24 h-24 rounded-full bg-gradient-to-br from-blue-500/20 to-transparent blur-xl" />

        {/* Main sphere */}
        <div
          className={`relative w-24 h-24 rounded-full overflow-hidden transition-all duration-300 ${
            isListening || isSpeaking || isResponding ? 'scale-110' : 'scale-100'
          }`}
        >
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 to-slate-800 rounded-full" />

          {/* Border */}
          <div className="absolute inset-0 rounded-full border border-slate-700/50" />

          {/* Listening pulse */}
          {isListening && (
            <div className="absolute inset-0 rounded-full border-2 border-blue-500/50 animate-pulse" />
          )}

          {/* Speaking animation */}
          {(isSpeaking || isResponding) && (
            <div className="absolute inset-0 rounded-full border-2 border-blue-400/30 animate-spin" style={{ animationDuration: '3s' }} />
          )}

          {/* Center content */}
          <div className="absolute inset-0 flex items-center justify-center">
            {isListening ? (
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-pulse" />
                <svg className="absolute inset-2 w-6 h-6 text-blue-400" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z" />
                </svg>
              </div>
            ) : isSpeaking || isResponding ? (
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-blue-500/20 rounded-full" />
                <div className="absolute inset-2 flex items-center justify-center gap-1">
                  <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                  <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="w-1 h-4 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
              </div>
            ) : (
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 to-blue-600/20 rounded-full" />
                <div className="absolute inset-2 w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-500 flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full" />
                </div>
              </div>
            )}
          </div>

          {/* Reflection */}
          <div className="absolute top-2 left-2 w-4 h-4 bg-white/10 rounded-full blur-sm" />
        </div>

        {/* Click to toggle listening */}
        <button
          onClick={() => {
            if (isSpeaking) {
              stopSpeech();
            } else {
              toggleListening();
            }
          }}
          className="absolute inset-0 rounded-full cursor-pointer focus:outline-none"
        />
      </div>
    </div>
  );
}
