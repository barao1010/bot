import { useState, useRef, useEffect, useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function InfinitoSphere() {
  const [isResponding, setIsResponding] = useState(false);
  const [conversationId] = useState<number>(1);
  const [animationIntensity, setAnimationIntensity] = useState(0);
  const [textInput, setTextInput] = useState('');
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string; audioUrl?: string }>>([]);
  const animationFrameRef = useRef<number | null>(null);
  const processingRef = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isSpeakingRef = useRef(false);

  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: (response) => {
      console.log('[Infinito] Resposta do LLM:', response);
      
      // Add assistant message
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.content
      }]);
      
      // Synthesize speech with ElevenLabs
      synthesizeSpeech(response.content);
      
      setTextInput('');
    },
    onError: (error) => {
      console.error('[Infinito] Erro:', error);
      toast.error('Erro ao processar sua solicitação');
      setIsResponding(false);
      setAnimationIntensity(0);
      processingRef.current = false;
    },
  });

  const synthesizeSpeech = useCallback(async (text: string) => {
    try {
      console.log('[Infinito] Sintetizando fala com ElevenLabs...');
      setAnimationIntensity(0.7);
      isSpeakingRef.current = true;

      const response = await fetch('/api/trpc/voice.synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          voiceId: 'Jarvis',
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.result?.data?.audio) {
        console.log('[Infinito] Áudio recebido, reproduzindo...');
        
        // Decode base64 to blob
        const binaryString = atob(data.result.data.audio);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const audioBlob = new Blob([bytes], { type: 'audio/mpeg' });
        const audioUrl = URL.createObjectURL(audioBlob);

        // Create or reuse audio element
        if (!audioRef.current) {
          audioRef.current = new Audio();
        }

        audioRef.current.src = audioUrl;
        audioRef.current.volume = 1;

        audioRef.current.onplay = () => {
          console.log('[Infinito] Começando a falar');
          setAnimationIntensity(0.8);
        };

        audioRef.current.onended = () => {
          console.log('[Infinito] Terminou de falar');
          setAnimationIntensity(0);
          setIsResponding(false);
          processingRef.current = false;
          isSpeakingRef.current = false;
          URL.revokeObjectURL(audioUrl);
        };

        audioRef.current.onerror = (error) => {
          console.error('[Infinito] Erro ao reproduzir áudio:', error);
          setAnimationIntensity(0);
          setIsResponding(false);
          processingRef.current = false;
          isSpeakingRef.current = false;
          URL.revokeObjectURL(audioUrl);
          toast.error('Erro ao reproduzir áudio');
        };

        await audioRef.current.play();
      } else {
        throw new Error('Nenhum áudio recebido');
      }
    } catch (error) {
      console.error('[Infinito] Erro ao sintetizar fala:', error);
      setAnimationIntensity(0);
      setIsResponding(false);
      processingRef.current = false;
      isSpeakingRef.current = false;
      toast.error('Erro ao gerar áudio');
    }
  }, []);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!text.trim() || processingRef.current || isResponding) return;

    console.log('[Infinito] Enviando mensagem:', text);
    processingRef.current = true;
    setIsResponding(true);
    setAnimationIntensity(0.7);

    setMessages(prev => [...prev, {
      role: 'user',
      content: text
    }]);

    try {
      await sendMessageMutation.mutateAsync({
        conversationId,
        content: text,
      });
    } catch (error) {
      console.error('[Infinito] Erro ao enviar mensagem:', error);
      processingRef.current = false;
      setIsResponding(false);
      setAnimationIntensity(0);
    }
  }, [conversationId, sendMessageMutation, isResponding]);

  const handleTextSubmit = useCallback(() => {
    if (textInput.trim()) {
      handleSendMessage(textInput);
    }
  }, [textInput, handleSendMessage]);

  // Animate sphere based on response
  useEffect(() => {
    if (isResponding || isSpeakingRef.current) {
      let intensity = 0;
      const animate = () => {
        intensity = (intensity + 0.05) % 1;
        setAnimationIntensity(0.5 + Math.sin(intensity * Math.PI * 2) * 0.3);
        animationFrameRef.current = requestAnimationFrame(animate);
      };
      animationFrameRef.current = requestAnimationFrame(animate);

      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }
  }, [isResponding]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-black overflow-hidden">
      {/* Subtle grid background */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="w-full h-full" style={{
          backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(59, 130, 246, 0.05) 25%, rgba(59, 130, 246, 0.05) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, 0.05) 75%, rgba(59, 130, 246, 0.05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(59, 130, 246, 0.05) 25%, rgba(59, 130, 246, 0.05) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, 0.05) 75%, rgba(59, 130, 246, 0.05) 76%, transparent 77%, transparent)',
          backgroundSize: '50px 50px',
        }} />
      </div>

      {/* Chat messages area */}
      <div className="flex-1 w-full max-w-2xl overflow-y-auto px-4 py-8 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <p className="text-blue-300/70 text-lg font-light">Olá! Sou o Infinito</p>
              <p className="text-blue-300/50 text-sm mt-2">Digite sua mensagem para começar</p>
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs px-4 py-3 rounded-lg ${
                  msg.role === 'user'
                    ? 'bg-blue-600/50 text-white'
                    : 'bg-blue-900/30 text-blue-100'
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.content}</p>
              </div>
            </div>
          ))
        )}
        {isResponding && (
          <div className="flex justify-start">
            <div className="bg-blue-900/30 text-blue-100 px-4 py-3 rounded-lg">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main sphere */}
      <div className="relative flex items-center justify-center mb-8">
        {/* Outer glow */}
        <div 
          className="absolute inset-0 rounded-full transition-all duration-300"
          style={{
            width: `${128 + animationIntensity * 40}px`,
            height: `${128 + animationIntensity * 40}px`,
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          <div 
            className="w-full h-full rounded-full blur-3xl transition-all duration-300"
            style={{
              background: `radial-gradient(circle, rgba(59, 130, 246, ${0.2 + animationIntensity * 0.3}) 0%, transparent 70%)`,
            }}
          />
        </div>

        {/* Pulsing rings during response */}
        {(isResponding || isSpeakingRef.current) && (
          <>
            <div 
              className="absolute rounded-full border border-blue-400/30"
              style={{
                width: '180px',
                height: '180px',
                animation: `pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite`,
              }}
            />
            <div 
              className="absolute rounded-full border border-blue-300/20"
              style={{
                width: '220px',
                height: '220px',
                animation: `pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite 0.3s`,
              }}
            />
          </>
        )}

        {/* Main sphere */}
        <div
          className="relative w-32 h-32 rounded-full transition-all duration-300 transform"
          style={{
            transform: `scale(${1 + animationIntensity * 0.15})`,
          }}
        >
          {/* Gradient background */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600" />

          {/* Animated border */}
          <div 
            className="absolute inset-0 rounded-full border-2 transition-all duration-300"
            style={{
              borderColor: `rgba(219, 234, 254, ${0.3 + animationIntensity * 0.7})`,
              animation: (isResponding || isSpeakingRef.current) ? `spin 3s linear infinite` : 'none',
            }}
          />

          {/* Inner light effect */}
          <div className="absolute inset-2 rounded-full bg-gradient-to-br from-blue-300/30 to-transparent" />

          {/* Center content */}
          <div className="absolute inset-0 flex items-center justify-center">
            {isResponding || isSpeakingRef.current ? (
              // Speaking animation
              <div className="relative w-12 h-12 flex items-center justify-center gap-1">
                <div 
                  className="w-1.5 rounded-full"
                  style={{
                    height: `${24 + Math.sin(Date.now() / 100) * 8}px`,
                    background: 'rgba(255, 255, 255, 0.8)',
                  }}
                />
                <div 
                  className="w-1.5 rounded-full"
                  style={{
                    height: `${32 + Math.sin(Date.now() / 100 + Math.PI / 3) * 8}px`,
                    background: 'rgba(255, 255, 255, 0.9)',
                  }}
                />
                <div 
                  className="w-1.5 rounded-full"
                  style={{
                    height: `${24 + Math.sin(Date.now() / 100 + 2 * Math.PI / 3) * 8}px`,
                    background: 'rgba(255, 255, 255, 0.8)',
                  }}
                />
              </div>
            ) : (
              // Idle state
              <div className="relative w-8 h-8 rounded-full bg-white/30 flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full" />
              </div>
            )}
          </div>

          {/* Reflection highlight */}
          <div className="absolute top-3 left-3 w-6 h-6 bg-white/20 rounded-full blur-sm" />
        </div>

        {/* Status text */}
        <div className="absolute -bottom-12 text-center">
          <p className="text-sm text-blue-300/70 font-light tracking-wider">
            {isResponding ? 'Processando...' :
             isSpeakingRef.current ? 'Falando...' :
             'Pronto para ouvir'}
          </p>
        </div>
      </div>

      {/* Input area */}
      <div className="w-full max-w-2xl px-4 pb-8 pt-16">
        <div className="flex gap-2">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleTextSubmit()}
            placeholder="Digite sua mensagem..."
            className="flex-1 px-4 py-3 rounded-lg bg-blue-900/30 text-white placeholder-blue-300/50 border border-blue-400/30 focus:outline-none focus:border-blue-400/70 transition-colors"
            disabled={isResponding}
            autoFocus
          />
          <button
            onClick={handleTextSubmit}
            disabled={isResponding || !textInput.trim()}
            className="px-6 py-3 rounded-lg bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white transition-colors font-medium"
          >
            Enviar
          </button>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
