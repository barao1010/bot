import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface JarvisAnimatedSphereProps {
  isResponding?: boolean;
  isSpeaking?: boolean;
  animationIntensity?: number;
}

export default function JarvisAnimatedSphere({
  isResponding = false,
  isSpeaking = false,
  animationIntensity = 0,
}: JarvisAnimatedSphereProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sphereRef = useRef<THREE.Group | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const animationIdRef = useRef<number | null>(null);
  const rotationRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // slate-950
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 3;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Create sphere group
    const sphereGroup = new THREE.Group();
    sphereRef.current = sphereGroup;
    scene.add(sphereGroup);

    // Main sphere with gradient
    const sphereGeometry = new THREE.IcosahedronGeometry(1, 32);
    const sphereMaterial = new THREE.MeshPhongMaterial({
      color: 0x0ea5e9, // blue-500
      emissive: 0x0284c7, // blue-600
      shininess: 100,
      wireframe: false,
    });
    const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
    sphereGroup.add(sphere);

    // Create energy field particles (circuit-like pattern)
    const particleCount = 2000;
    const particlesGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      // Create particles on sphere surface and around it
      const radius = 1 + Math.random() * 0.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;

      particlePositions[i3] = radius * Math.sin(phi) * Math.cos(theta);
      particlePositions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      particlePositions[i3 + 2] = radius * Math.cos(phi);

      // Blue color with variation
      particleColors[i3] = 0.2 + Math.random() * 0.8; // R
      particleColors[i3 + 1] = 0.6 + Math.random() * 0.4; // G
      particleColors[i3 + 2] = 0.9 + Math.random() * 0.1; // B
    }

    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particlesGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.02,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
    });

    const particles = new THREE.Points(particlesGeometry, particlesMaterial);
    particlesRef.current = particles;
    sphereGroup.add(particles);

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x0ea5e9, 1);
    pointLight1.position.set(5, 5, 5);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x06b6d4, 0.5);
    pointLight2.position.set(-5, -5, 5);
    scene.add(pointLight2);

    // Add glow effect using post-processing (simplified)
    const glowGeometry = new THREE.IcosahedronGeometry(1.1, 32);
    const glowMaterial = new THREE.MeshBasicMaterial({
      color: 0x0ea5e9,
      transparent: true,
      opacity: 0.15,
      side: THREE.BackSide,
    });
    const glowMesh = new THREE.Mesh(glowGeometry, glowMaterial);
    sphereGroup.add(glowMesh);

    // Animation loop
    let time = 0;
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      time += 0.01;

      // Rotate sphere
      sphere.rotation.x += 0.0005;
      sphere.rotation.y += 0.0008;

      // Rotate particles
      if (particles) {
        particles.rotation.x += 0.0003;
        particles.rotation.y += 0.0005;
      }

      // Pulsate sphere based on animation intensity
      const scale = 1 + animationIntensity * 0.1;
      sphere.scale.set(scale, scale, scale);
      glowMesh.scale.set(scale * 1.1, scale * 1.1, scale * 1.1);

      // Update particle opacity based on speaking state
      if (isSpeaking || isResponding) {
        particlesMaterial.opacity = 0.6 + Math.sin(time * 3) * 0.2;
      } else {
        particlesMaterial.opacity = 0.4;
      }

      // Update glow opacity
      glowMaterial.opacity = 0.1 + animationIntensity * 0.15;

      renderer.render(scene, camera);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
      sphereGeometry.dispose();
      sphereMaterial.dispose();
      particlesGeometry.dispose();
      particlesMaterial.dispose();
      glowGeometry.dispose();
      glowMaterial.dispose();
    };
  }, []);

  // Update animation based on props
  useEffect(() => {
    if (!sphereRef.current) return;

    const sphere = sphereRef.current.children[0] as THREE.Mesh;
    if (sphere && isSpeaking) {
      // Add pulsing effect when speaking
      const pulseScale = 1 + Math.sin(Date.now() / 100) * 0.05;
      sphere.scale.set(pulseScale, pulseScale, pulseScale);
    }
  }, [isSpeaking, animationIntensity]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full"
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
      }}
    />
  );
}
