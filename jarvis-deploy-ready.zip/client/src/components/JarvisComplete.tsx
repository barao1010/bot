import { useState, useRef, useEffect, useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import JarvisAnimatedSphere from './JarvisAnimatedSphere';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  audioUrl?: string;
}

export default function JarvisComplete() {
  const [isResponding, setIsResponding] = useState(false);
  const [conversationId] = useState<number>(1);
  const [animationIntensity, setAnimationIntensity] = useState(0);
  const [textInput, setTextInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [responseMode, setResponseMode] = useState<'text' | 'audio' | 'both'>('both');
  const [selectedVoice, setSelectedVoice] = useState('alloy');

  const animationFrameRef = useRef<number | null>(null);
  const processingRef = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isSpeakingRef = useRef(false);

  // Mutations
  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: (response) => {
      console.log('[Jarvis] Resposta do LLM:', response);
      
      // Add assistant message
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.content
      }]);
      
      // If audio response is enabled, synthesize speech
      if (responseMode === 'audio' || responseMode === 'both') {
        synthesizeSpeech(response.content);
      } else {
        setIsResponding(false);
        setAnimationIntensity(0);
        processingRef.current = false;
      }
      
      setTextInput('');
    },
    onError: (error) => {
      console.error('[Jarvis] Erro:', error);
      toast.error('Erro ao processar sua solicitação');
      setIsResponding(false);
      setAnimationIntensity(0);
      processingRef.current = false;
    },
  });

  const synthesizeSpeech = useCallback(async (text: string) => {
    try {
      console.log('[Jarvis] Sintetizando fala com OpenAI TTS...');
      setAnimationIntensity(0.7);
      isSpeakingRef.current = true;
      setIsSpeaking(true);

      const response = await fetch('/api/trpc/voice.synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          voiceId: selectedVoice,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.result?.data?.audio) {
        console.log('[Jarvis] Áudio recebido, reproduzindo...');
        
        // Decode base64 to blob
        const binaryString = atob(data.result.data.audio);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const audioBlob = new Blob([bytes], { type: 'audio/mpeg' });
        const audioUrl = URL.createObjectURL(audioBlob);

        // Create or reuse audio element
        if (!audioRef.current) {
          audioRef.current = new Audio();
        }
        audioRef.current.src = audioUrl;
        audioRef.current.volume = 1;

        audioRef.current.onplay = () => {
          console.log('[Jarvis] Começando a falar');
          setAnimationIntensity(0.8);
        };

        audioRef.current.onended = () => {
          console.log('[Jarvis] Terminou de falar');
          setAnimationIntensity(0);
          setIsResponding(false);
          setIsSpeaking(false);
          processingRef.current = false;
          isSpeakingRef.current = false;
          URL.revokeObjectURL(audioUrl);
        };

        audioRef.current.onerror = (error) => {
          console.error('[Jarvis] Erro ao reproduzir áudio:', error);
          setAnimationIntensity(0);
          setIsResponding(false);
          setIsSpeaking(false);
          processingRef.current = false;
          isSpeakingRef.current = false;
          URL.revokeObjectURL(audioUrl);
          toast.error('Erro ao reproduzir áudio');
        };

        await audioRef.current.play();
      } else {
        throw new Error('Nenhum áudio recebido');
      }
    } catch (error) {
      console.error('[Jarvis] Erro ao sintetizar fala:', error);
      setAnimationIntensity(0);
      setIsResponding(false);
      setIsSpeaking(false);
      processingRef.current = false;
      isSpeakingRef.current = false;
      toast.error('Erro ao gerar áudio');
    }
  }, [selectedVoice]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!text.trim() || processingRef.current || isResponding) return;
    
    console.log('[Jarvis] Enviando mensagem:', text);
    processingRef.current = true;
    setIsResponding(true);
    setAnimationIntensity(0.7);

    setMessages(prev => [...prev, {
      role: 'user',
      content: text
    }]);

    try {
      await sendMessageMutation.mutateAsync({
        conversationId,
        content: text,
      });
    } catch (error) {
      console.error('[Jarvis] Erro ao enviar mensagem:', error);
      processingRef.current = false;
      setIsResponding(false);
      setAnimationIntensity(0);
    }
  }, [conversationId, sendMessageMutation, isResponding]);

  const handleTextSubmit = useCallback(() => {
    if (textInput.trim()) {
      handleSendMessage(textInput);
    }
  }, [textInput, handleSendMessage]);

  // Animate sphere based on response
  useEffect(() => {
    if (isResponding || isSpeakingRef.current) {
      let intensity = 0;
      const animate = () => {
        intensity = (intensity + 0.05) % 1;
        setAnimationIntensity(0.5 + Math.sin(intensity * Math.PI * 2) * 0.3);
        animationFrameRef.current = requestAnimationFrame(animate);
      };
      animationFrameRef.current = requestAnimationFrame(animate);
      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }
  }, [isResponding]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-black overflow-hidden">
      {/* Subtle grid background */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="w-full h-full" style={{
          backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(59, 130, 246, 0.05) 25%, rgba(59, 130, 246, 0.05) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, 0.05) 75%, rgba(59, 130, 246, 0.05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(59, 130, 246, 0.05) 25%, rgba(59, 130, 246, 0.05) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, 0.05) 75%, rgba(59, 130, 246, 0.05) 76%, transparent 77%, transparent)',
          backgroundSize: '50px 50px',
        }} />
      </div>

      {/* Chat messages area */}
      <div className="flex-1 w-full max-w-3xl overflow-y-auto px-4 py-8 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <p className="text-blue-300/70 text-lg font-light">Olá! Sou o Jarvis</p>
              <p className="text-blue-300/50 text-sm mt-2">Digite sua mensagem para começar</p>
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs px-4 py-3 rounded-lg ${
                  msg.role === 'user'
                    ? 'bg-blue-600/50 text-white'
                    : 'bg-blue-900/30 text-blue-100 border border-blue-400/30'
                }`}
              >
                <p className="text-sm">{msg.content}</p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Animated Sphere - 3D */}
      <div className="w-96 h-96 mb-8">
        <JarvisAnimatedSphere 
          isResponding={isResponding}
          isSpeaking={isSpeaking}
          animationIntensity={animationIntensity}
        />
      </div>

      {/* Status text */}
      <div className="text-center mb-4">
        <p className="text-sm text-blue-300/70 font-light tracking-wider">
          {isResponding ? 'Processando...' :
           isSpeaking ? 'Falando...' :
           'Pronto para ouvir'}
        </p>
      </div>

      {/* Controls */}
      <div className="w-full max-w-3xl px-4 pb-8 space-y-4">
        {/* Response Mode Selection */}
        <div className="flex gap-2 justify-center">
          <button
            onClick={() => setResponseMode('text')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              responseMode === 'text'
                ? 'bg-blue-500 text-white'
                : 'bg-blue-900/30 text-blue-300 hover:bg-blue-900/50'
            }`}
          >
            Apenas Texto
          </button>
          <button
            onClick={() => setResponseMode('audio')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              responseMode === 'audio'
                ? 'bg-blue-500 text-white'
                : 'bg-blue-900/30 text-blue-300 hover:bg-blue-900/50'
            }`}
          >
            Apenas Áudio
          </button>
          <button
            onClick={() => setResponseMode('both')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              responseMode === 'both'
                ? 'bg-blue-500 text-white'
                : 'bg-blue-900/30 text-blue-300 hover:bg-blue-900/50'
            }`}
          >
            Texto + Áudio
          </button>
        </div>

        {/* Voice Selection */}
        <div className="flex gap-2 items-center justify-center">
          <label className="text-sm text-blue-300/70">Voz:</label>
          <select
            value={selectedVoice}
            onChange={(e) => setSelectedVoice(e.target.value)}
            className="px-3 py-2 rounded-lg bg-blue-900/30 text-white text-sm border border-blue-400/30 focus:outline-none focus:border-blue-400/70"
          >
            <option value="alloy">Alloy (Jarvis)</option>
            <option value="echo">Echo</option>
            <option value="fable">Fable</option>
            <option value="onyx">Onyx</option>
            <option value="nova">Nova</option>
            <option value="shimmer">Shimmer</option>
          </select>
        </div>

        {/* Input area */}
        <div className="flex gap-2">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleTextSubmit()}
            placeholder="Digite sua mensagem..."
            className="flex-1 px-4 py-3 rounded-lg bg-blue-900/30 text-white placeholder-blue-300/50 border border-blue-400/30 focus:outline-none focus:border-blue-400/70 transition-colors"
            disabled={isResponding}
            autoFocus
          />
          <button
            onClick={handleTextSubmit}
            disabled={isResponding || !textInput.trim()}
            className="px-6 py-3 rounded-lg bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white transition-colors font-medium"
          >
            Enviar
          </button>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
