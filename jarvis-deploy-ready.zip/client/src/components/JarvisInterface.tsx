import { useState, useEffect } from 'react';
import { Mic, Send, Menu, X, Volume2, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function JarvisInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Olá, sou Jarvis. Como posso ajudá-lo hoje?',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Entendi sua solicitação. Processando...',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1000);
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
  };

  return (
    <div className="cinematic-bg min-h-screen flex flex-col overflow-hidden">
      {/* Animated background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-orange-500/5 animate-pulse" />
      </div>

      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="hover:bg-cyan-500/10"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
            <h1 className="neon-text text-2xl font-bold tracking-wider">JARVIS</h1>
          </div>
          <Button variant="ghost" size="icon" className="hover:bg-orange-500/10">
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden gap-4 p-4">
        {/* Sidebar */}
        {isSidebarOpen && (
          <div className="w-64 border border-cyan-500/20 rounded-lg bg-card/50 backdrop-blur-sm p-4 overflow-y-auto holographic-glow">
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-cyan-400 uppercase tracking-widest">
                Histórico
              </h2>
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <button
                    key={i}
                    className="w-full text-left text-xs p-2 rounded border border-cyan-500/20 hover:bg-cyan-500/10 transition-colors text-foreground/70 hover:text-foreground"
                  >
                    Conversa {i}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col gap-4">
          {/* Messages Container */}
          <Card className="flex-1 overflow-y-auto border-cyan-500/20 bg-card/30 backdrop-blur-sm p-6 space-y-4 holographic-glow">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} fade-in`}
              >
                <div
                  className={`max-w-md px-4 py-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-orange-500/20 border border-orange-500/30 text-foreground'
                      : 'bg-cyan-500/20 border border-cyan-500/30 text-foreground'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <span className="text-xs text-foreground/50 mt-1 block">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-cyan-500/20 border border-cyan-500/30 px-4 py-3 rounded-lg">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-100" />
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              </div>
            )}
          </Card>

          {/* Input Area */}
          <div className="border border-cyan-500/20 rounded-lg bg-card/50 backdrop-blur-sm p-4 holographic-glow">
            <div className="flex gap-3">
              <Button
                onClick={handleVoiceInput}
                variant={isListening ? 'default' : 'outline'}
                size="icon"
                className={`${
                  isListening
                    ? 'bg-orange-500/30 border-orange-500/50 hover:bg-orange-500/40'
                    : 'border-cyan-500/30 hover:bg-cyan-500/10'
                }`}
              >
                <Mic className={`w-5 h-5 ${isListening ? 'animate-pulse' : ''}`} />
              </Button>

              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Fale com Jarvis..."
                className="bg-background/50 border-cyan-500/20 focus:border-cyan-500/50 focus:ring-cyan-500/30"
              />

              <Button
                onClick={handleSendMessage}
                disabled={!input.trim() || isLoading}
                className="bg-gradient-to-r from-cyan-500/50 to-orange-500/50 hover:from-cyan-500/70 hover:to-orange-500/70 border border-cyan-500/30"
              >
                <Send className="w-5 h-5" />
              </Button>

              <Button
                variant="outline"
                size="icon"
                className="border-cyan-500/30 hover:bg-cyan-500/10"
              >
                <Volume2 className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
