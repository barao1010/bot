import { useCallback, useRef } from 'react';

export function useElevenLabsVoice() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isPlayingRef = useRef(false);

  const speak = useCallback(async (text: string, onStart?: () => void, onEnd?: () => void) => {
    if (!text.trim()) return;

    try {
      // Stop any existing audio
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }

      onStart?.();
      isPlayingRef.current = true;

      // Call backend to get audio from ElevenLabs
      const response = await fetch('/api/trpc/voice.synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          voiceId: 'Jarvis', // Will use Jarvis voice ID from backend
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Get audio blob
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);

      // Create or reuse audio element
      if (!audioRef.current) {
        audioRef.current = new Audio();
      }

      audioRef.current.src = audioUrl;
      audioRef.current.onended = () => {
        isPlayingRef.current = false;
        onEnd?.();
        URL.revokeObjectURL(audioUrl);
      };

      audioRef.current.onerror = () => {
        isPlayingRef.current = false;
        onEnd?.();
        URL.revokeObjectURL(audioUrl);
      };

      await audioRef.current.play();
    } catch (error) {
      console.error('[ElevenLabs] Erro ao sintetizar fala:', error);
      isPlayingRef.current = false;
      onEnd?.();
    }
  }, []);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    isPlayingRef.current = false;
  }, []);

  return {
    speak,
    stop,
    isPlaying: isPlayingRef.current,
  };
}
