import { useState, useCallback, useRef, useEffect } from 'react';

interface UseTextToSpeechProps {
  rate?: number;
  pitch?: number;
  volume?: number;
  lang?: string;
}

export function useTextToSpeech({
  rate = 1,
  pitch = 1,
  volume = 1,
  lang = 'pt-BR',
}: UseTextToSpeechProps = {}) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Initialize speech synthesis
  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis || (window as any).webkitSpeechSynthesis;
    }
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!text.trim()) {
        console.warn('[TTS] Empty text provided');
        return;
      }

      const synth = synthRef.current;
      if (!synth) {
        console.error('[TTS] Speech Synthesis not available');
        return;
      }

      try {
        console.log('[TTS] Speaking:', text.substring(0, 100));
        synth.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = Math.max(0.1, Math.min(2, rate));
        utterance.pitch = Math.max(0.1, Math.min(2, pitch));
        utterance.volume = Math.max(0, Math.min(1, volume));
        utterance.lang = lang;

        // Try to get Portuguese voice
        const voices = synth.getVoices();
        const portugueseVoice = voices.find(
          (voice) => voice.lang.includes('pt') && voice.name.includes('Google')
        ) || voices.find((voice) => voice.lang.includes('pt'));

        if (portugueseVoice) {
          utterance.voice = portugueseVoice;
          console.log('[TTS] Using voice:', portugueseVoice.name);
        }

        utterance.onstart = () => {
          console.log('[TTS] Started speaking');
          setIsSpeaking(true);
          setIsPaused(false);
        };

        utterance.onend = () => {
          console.log('[TTS] Finished speaking');
          setIsSpeaking(false);
          setIsPaused(false);
        };

        utterance.onerror = (event) => {
          console.error('[TTS] Error:', event.error);
          setIsSpeaking(false);
          setIsPaused(false);
        };

        utteranceRef.current = utterance;
        synth.speak(utterance);
      } catch (error) {
        console.error('[TTS] Exception:', error);
        setIsSpeaking(false);
      }
    },
    [rate, pitch, volume, lang]
  );

  const pause = useCallback(() => {
    const synth = synthRef.current;
    if (synth && synth.speaking && !synth.paused) {
      try {
        synth.pause();
        setIsPaused(true);
        console.log('[TTS] Paused');
      } catch (error) {
        console.error('[TTS] Pause error:', error);
      }
    }
  }, []);

  const resume = useCallback(() => {
    const synth = synthRef.current;
    if (synth && synth.paused) {
      try {
        synth.resume();
        setIsPaused(false);
        console.log('[TTS] Resumed');
      } catch (error) {
        console.error('[TTS] Resume error:', error);
      }
    }
  }, []);

  const stop = useCallback(() => {
    const synth = synthRef.current;
    if (synth) {
      try {
        synth.cancel();
        setIsSpeaking(false);
        setIsPaused(false);
        console.log('[TTS] Stopped');
      } catch (error) {
        console.error('[TTS] Stop error:', error);
      }
    }
  }, []);

  const togglePause = useCallback(() => {
    if (isPaused) {
      resume();
    } else if (isSpeaking) {
      pause();
    }
  }, [isPaused, isSpeaking, pause, resume]);

  return {
    isSpeaking,
    isPaused,
    speak,
    pause,
    resume,
    stop,
    togglePause,
  };
}
