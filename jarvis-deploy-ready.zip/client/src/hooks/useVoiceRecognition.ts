import { useState, useCallback, useRef, useEffect } from 'react';

interface UseVoiceRecognitionProps {
  onTranscript?: (transcript: string) => void;
  onError?: (error: string) => void;
  onSpeechStart?: () => void;
  onSpeechEnd?: () => void;
  language?: string;
  continuous?: boolean;
}

export function useVoiceRecognition({
  onTranscript,
  onError,
  onSpeechStart,
  onSpeechEnd,
  language = 'pt-BR',
  continuous = true,
}: UseVoiceRecognitionProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  
  const recognitionRef = useRef<any>(null);
  const finalTranscriptRef = useRef('');
  const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isStartingRef = useRef(false);
  const shouldContinueRef = useRef(continuous);
  const callbacksRef = useRef({ onTranscript, onError, onSpeechStart, onSpeechEnd });

  // Update callbacks ref without recreating recognition
  useEffect(() => {
    callbacksRef.current = { onTranscript, onError, onSpeechStart, onSpeechEnd };
  }, [onTranscript, onError, onSpeechStart, onSpeechEnd]);

  // Initialize recognition once, no automatic start
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      console.error('[VoiceRecognition] Speech Recognition não suportado');
      callbacksRef.current.onError?.('Speech Recognition não suportado neste navegador');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = language;

    recognition.onstart = () => {
      console.log('[VoiceRecognition] Started');
      setIsListening(true);
      isStartingRef.current = false;
      callbacksRef.current.onSpeechStart?.();
    };

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let hasFinalResult = false;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;

        if (event.results[i].isFinal) {
          finalTranscriptRef.current += transcript + ' ';
          hasFinalResult = true;
        } else {
          interimTranscript += transcript;
        }
      }

      if (hasFinalResult || interimTranscript) {
        setIsSpeaking(true);

        // Clear existing timeout
        if (silenceTimeoutRef.current) {
          clearTimeout(silenceTimeoutRef.current);
        }

        // Set timeout for silence detection (2 seconds)
        silenceTimeoutRef.current = setTimeout(() => {
          console.log('[VoiceRecognition] Silence detected');
          setIsSpeaking(false);
          callbacksRef.current.onSpeechEnd?.();

          if (finalTranscriptRef.current.trim()) {
            console.log('[VoiceRecognition] Final transcript:', finalTranscriptRef.current);
            callbacksRef.current.onTranscript?.(finalTranscriptRef.current.trim());
            finalTranscriptRef.current = '';
          }

          // Restart only if continuous and should continue
          if (shouldContinueRef.current && recognitionRef.current && !isStartingRef.current) {
            try {
              console.log('[VoiceRecognition] Restarting for next command');
              isStartingRef.current = true;
              recognitionRef.current.stop();
              setTimeout(() => {
                if (shouldContinueRef.current && recognitionRef.current && !isStartingRef.current) {
                  try {
                    recognitionRef.current.start();
                  } catch (e) {
                    console.error('[VoiceRecognition] Error restarting:', e);
                    isStartingRef.current = false;
                  }
                }
              }, 300);
            } catch (e) {
              console.error('[VoiceRecognition] Error in restart:', e);
              isStartingRef.current = false;
            }
          }
        }, 2000);
      }

      const fullTranscript = finalTranscriptRef.current + interimTranscript;
      setTranscript(fullTranscript);
    };

    recognition.onerror = (event: any) => {
      console.error('[VoiceRecognition] Error:', event.error);
      isStartingRef.current = false;
      
      // Only report non-transient errors
      if (event.error === 'not-allowed') {
        callbacksRef.current.onError?.('Permissão de microfone negada');
      } else if (event.error === 'network') {
        callbacksRef.current.onError?.('Erro de conexão');
      } else if (event.error === 'no-speech') {
        console.log('[VoiceRecognition] No speech detected');
      } else if (event.error !== 'aborted') {
        callbacksRef.current.onError?.(`Erro: ${event.error}`);
      }
    };

    recognition.onend = () => {
      console.log('[VoiceRecognition] Ended');
      setIsListening(false);
      isStartingRef.current = false;
    };

    recognitionRef.current = recognition;

    return () => {
      if (silenceTimeoutRef.current) {
        clearTimeout(silenceTimeoutRef.current);
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {
          console.error('[VoiceRecognition] Error aborting:', e);
        }
      }
    };
  }, [language]);

  // Update shouldContinue when continuous prop changes
  useEffect(() => {
    shouldContinueRef.current = continuous;
  }, [continuous]);

  const startListening = useCallback(() => {
    if (!recognitionRef.current) {
      console.error('[VoiceRecognition] Recognition not initialized');
      return;
    }

    if (isStartingRef.current || isListening) {
      console.log('[VoiceRecognition] Already starting or listening');
      return;
    }

    try {
      console.log('[VoiceRecognition] Starting listening...');
      isStartingRef.current = true;
      shouldContinueRef.current = true;
      finalTranscriptRef.current = '';
      recognitionRef.current.start();
    } catch (error) {
      console.error('[VoiceRecognition] Error starting:', error);
      isStartingRef.current = false;
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (!recognitionRef.current) return;

    try {
      console.log('[VoiceRecognition] Stopping listening...');
      shouldContinueRef.current = false;
      if (silenceTimeoutRef.current) {
        clearTimeout(silenceTimeoutRef.current);
      }
      recognitionRef.current.abort();
      setIsListening(false);
      setIsSpeaking(false);
    } catch (error) {
      console.error('[VoiceRecognition] Error stopping:', error);
    }
  }, []);

  return {
    isListening,
    isSpeaking,
    transcript,
    startListening,
    stopListening,
  };
}
