import InfinitoSphere from '@/components/InfinitoSphere';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Home() {
  const { user, loading } = useAuth();

  if (loading) {
    return null;
  }

  if (!user) {
    return null;
  }

  return <InfinitoSphere />;
}
