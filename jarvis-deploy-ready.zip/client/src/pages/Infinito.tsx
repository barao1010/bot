import { useState, useEffect } from 'react';
import InfinitoAvatar from '@/components/InfinitoAvatar';
import InfinitoChatWindow from '@/components/InfinitoChatWindow';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Infinito() {
  const { user, loading } = useAuth();
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isResponding, setIsResponding] = useState(false);

  useEffect(() => {
    // Initialize Service Worker for 24/7 availability
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.log('ServiceWorker registration failed: ', err);
      });
    }

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    // Prevent default scrolling behavior to keep avatar accessible
    const handleScroll = (e: WheelEvent) => {
      // Allow normal scrolling but keep avatar accessible
    };

    window.addEventListener('wheel', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('wheel', handleScroll);
    };
  }, []);

  if (loading) {
    return null;
  }

  if (!user) {
    return null;
  }

  return (
    <div className="fixed inset-0 pointer-events-none bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Subtle background grid */}
      <div className="fixed inset-0 cyber-grid opacity-5 pointer-events-none" />

      {/* Avatar - Always visible and interactive */}
      <div
        className="pointer-events-auto"
        onClick={() => setIsChatOpen(!isChatOpen)}
      >
        <InfinitoAvatar
          onClose={() => setIsChatOpen(false)}
          isListening={isListening}
          isResponding={isResponding}
          onMicClick={() => setIsListening(!isListening)}
        />
      </div>

      {/* Chat Window */}
      <div className="pointer-events-auto">
        <InfinitoChatWindow
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
        />
      </div>

      {/* Subtle ambient effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-slate-900/10" />
      </div>
    </div>
  );
}
