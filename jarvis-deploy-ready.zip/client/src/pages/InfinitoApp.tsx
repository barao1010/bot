import { useEffect } from 'react';
import InfinitoSphere from '@/components/InfinitoSphere';
import { useAuth } from '@/_core/hooks/useAuth';

export default function InfinitoApp() {
  const { user, loading } = useAuth();

  useEffect(() => {
    // Initialize Service Worker for 24/7 availability
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.log('ServiceWorker registration failed: ', err);
      });
    }

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    // Load voices for text-to-speech
    window.speechSynthesis.onvoiceschanged = () => {
      window.speechSynthesis.getVoices();
    };
  }, []);

  if (loading) {
    return null;
  }

  if (!user) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 overflow-hidden">
      {/* Subtle background grid */}
      <div className="fixed inset-0 cyber-grid opacity-5 pointer-events-none" />

      {/* Infinito Sphere - Main component */}
      <InfinitoSphere />

      {/* Subtle ambient effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-slate-900/10" />
      </div>
    </div>
  );
}
