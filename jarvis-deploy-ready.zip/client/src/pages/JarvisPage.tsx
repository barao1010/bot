import JarvisComplete from '@/components/JarvisComplete';
import { useAuth } from '@/_core/hooks/useAuth';

export default function JarvisPage() {
  const { user, loading } = useAuth();

  if (loading) {
    return null;
  }

  if (!user) {
    return null;
  }

  return <JarvisComplete />;
}
