import { useState, useEffect } from 'react';
import HolographicSphere from '@/components/HolographicSphere';
import FloatingChatPanel from '@/components/FloatingChatPanel';
import { useAuth } from '@/_core/hooks/useAuth';

export default function JarvisWidget() {
  const { user, loading } = useAuth();
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isResponding, setIsResponding] = useState(false);

  useEffect(() => {
    // Initialize Service Worker for 24/7 availability
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.log('ServiceWorker registration failed: ', err);
      });
    }

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  if (loading) {
    return null;
  }

  if (!user) {
    return null;
  }

  return (
    <div className="fixed inset-0 pointer-events-none">
      {/* Holographic Sphere - Always visible */}
      <div
        className="pointer-events-auto"
        onClick={() => setIsChatOpen(!isChatOpen)}
      >
        <HolographicSphere
          onClose={() => setIsChatOpen(false)}
          isListening={isListening}
          isResponding={isResponding}
        />
      </div>

      {/* Floating Chat Panel */}
      <div className="pointer-events-auto">
        <FloatingChatPanel
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          isMinimized={isMinimized}
          onToggleMinimize={() => setIsMinimized(!isMinimized)}
        />
      </div>

      {/* Background ambient effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-orange-500/5" />
      </div>
    </div>
  );
}
