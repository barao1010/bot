DROP TABLE `alerts`;--> statement-breakpoint
DROP TABLE `automations`;--> statement-breakpoint
DROP TABLE `conversations`;--> statement-breakpoint
DROP TABLE `generatedImages`;--> statement-breakpoint
DROP TABLE `messages`;--> statement-breakpoint
DROP TABLE `storedFiles`;--> statement-breakpoint
DROP TABLE `userMemory`;