import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  conversations,
  messages,
  userMemory,
  generatedImages,
  alerts,
  storedFiles,
  automations,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Chat and conversation queries
export async function createConversation(
  userId: number,
  title: string,
  summary?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(conversations).values({
    userId,
    title,
    summary,
  });
  
  // Get the inserted conversation
  const conversations_list = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(conversations.createdAt)
    .limit(1);
  
  return conversations_list[0] || { id: 1, userId, title, summary, createdAt: new Date(), updatedAt: new Date() };
}

export async function getConversations(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy((c) => c.createdAt);
}

export async function addMessage(
  conversationId: number,
  userId: number,
  role: "user" | "assistant" | "system",
  content: string,
  metadata?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(messages).values({
    conversationId,
    userId,
    role,
    content,
    metadata,
  });
}

export async function getMessages(conversationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy((m) => m.createdAt);
}

// User memory queries
export async function saveUserMemory(
  userId: number,
  key: string,
  value: string,
  category?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(userMemory).values({
    userId,
    key,
    value,
    category,
  });
}

export async function getUserMemory(userId: number, category?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (category) {
    return await db
      .select()
      .from(userMemory)
      .where(eq(userMemory.category, category));
  }
  
  return await db
    .select()
    .from(userMemory)
    .where(eq(userMemory.userId, userId));
}

// Generated images queries
export async function saveGeneratedImage(
  userId: number,
  prompt: string,
  imageUrl: string,
  imageKey: string,
  metadata?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(generatedImages).values({
    userId,
    prompt,
    imageUrl,
    imageKey,
    metadata,
  });
}

export async function getGeneratedImages(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(generatedImages)
    .where(eq(generatedImages.userId, userId))
    .orderBy((img) => img.createdAt);
}

// Alerts queries
export async function createAlert(
  userId: number,
  title: string,
  content: string,
  type: "info" | "warning" | "error" | "success" = "info"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(alerts).values({
    userId,
    title,
    content,
    type,
  });
}

export async function getAlerts(userId: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (unreadOnly) {
    return await db
      .select()
      .from(alerts)
      .where(and(eq(alerts.userId, userId), eq(alerts.isRead, false)))
      .orderBy((a) => a.createdAt);
  }
  
  return await db
    .select()
    .from(alerts)
    .where(eq(alerts.userId, userId))
    .orderBy((a) => a.createdAt);
}

// Stored files queries
export async function saveStoredFile(
  userId: number,
  filename: string,
  fileKey: string,
  fileUrl: string,
  mimeType?: string,
  fileSize?: number,
  category?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(storedFiles).values({
    userId,
    filename,
    fileKey,
    fileUrl,
    mimeType,
    fileSize,
    category,
  });
}

export async function getStoredFiles(userId: number, category?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (category) {
    return await db
      .select()
      .from(storedFiles)
      .where(and(eq(storedFiles.userId, userId), eq(storedFiles.category, category)))
      .orderBy((f) => f.createdAt);
  }
  
  return await db
    .select()
    .from(storedFiles)
    .where(eq(storedFiles.userId, userId))
    .orderBy((f) => f.createdAt);
}

// Automations queries
export async function createAutomation(
  userId: number,
  name: string,
  trigger: string,
  action: string,
  schedule?: string,
  description?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(automations).values({
    userId,
    name,
    trigger,
    action,
    schedule,
    description,
  });
}

export async function getAutomations(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(automations)
    .where(eq(automations.userId, userId))
    .orderBy((a) => a.createdAt);
}
