import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createAutomation,
  getAutomations,
  createAlert,
  getAlerts,
} from "../db";

export const automationRouter = router({
  // Create automation rule
  createAutomation: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        description: z.string().optional(),
        trigger: z.string(), // e.g., "time:09:00", "event:email", "command:jarvis"
        action: z.string(), // JSON stringified action
        schedule: z.string().optional(), // Cron expression
      })
    )
    .mutation(async ({ input, ctx }) => {
      return await createAutomation(
        ctx.user.id,
        input.name,
        input.trigger,
        input.action,
        input.schedule,
        input.description
      );
    }),

  // Get automations
  getAutomations: protectedProcedure.query(async ({ ctx }) => {
    return await getAutomations(ctx.user.id);
  }),

  // Create alert
  createAlert: protectedProcedure
    .input(
      z.object({
        title: z.string(),
        content: z.string(),
        type: z.enum(["info", "warning", "error", "success"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return await createAlert(
        ctx.user.id,
        input.title,
        input.content,
        (input.type as "info" | "warning" | "error" | "success") || "info"
      );
    }),

  // Get alerts
  getAlerts: protectedProcedure
    .input(z.object({ unreadOnly: z.boolean().optional() }))
    .query(async ({ input, ctx }) => {
      return await getAlerts(ctx.user.id, input.unreadOnly);
    }),

  // Example automation templates
  getAutomationTemplates: protectedProcedure.query(() => {
    return [
      {
        id: "daily-briefing",
        name: "Resumo Diário",
        description: "Receba um resumo das suas atividades diariamente",
        trigger: "time:09:00",
        action: JSON.stringify({
          type: "notification",
          message: "Seu resumo diário está pronto",
        }),
      },
      {
        id: "email-reminder",
        name: "Lembrete de Emails",
        description: "Seja notificado sobre novos emails importantes",
        trigger: "event:email",
        action: JSON.stringify({
          type: "notification",
          message: "Você tem um novo email importante",
        }),
      },
      {
        id: "weather-alert",
        name: "Alerta de Clima",
        description: "Receba alertas sobre mudanças de clima",
        trigger: "time:08:00",
        action: JSON.stringify({
          type: "notification",
          message: "Confira a previsão do tempo para hoje",
        }),
      },
      {
        id: "productivity-check",
        name: "Verificação de Produtividade",
        description: "Verificação periódica de suas tarefas",
        trigger: "time:12:00",
        action: JSON.stringify({
          type: "notification",
          message: "Como está sua produtividade hoje?",
        }),
      },
    ];
  }),
});
