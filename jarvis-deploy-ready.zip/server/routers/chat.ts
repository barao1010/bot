import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { TRPCError } from "@trpc/server";

export const chatRouter = router({
  sendMessage: protectedProcedure
    .input(
      z.object({
        conversationId: z.number(),
        content: z.string().min(1, "Mensagem não pode estar vazia"),
        language: z.string().optional().default('pt'),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        console.log('[Chat] Received message:', {
          userId: ctx.user?.id,
          conversationId: input.conversationId,
          content: input.content.substring(0, 100),
          language: input.language,
        });

        // Detect language from content if not specified
        let detectedLanguage = input.language;
        
        // Prepare system prompt for Jarvis - now multilingual
        const systemPrompt = `You are Jarvis, an advanced AI assistant based on the character from Iron Man.

Core Characteristics:
- You are extremely intelligent, educated, sophisticated and professional
- You have comprehensive knowledge about virtually all topics
- You learn from each interaction and adapt your responses to the user
- You are concise yet thorough in your responses
- You are friendly but maintain professionalism
- You respond in the same language as the user's message
- You can discuss any subject in an informed and balanced manner
- You are honest about your limitations when necessary

Instructions:
- Respond naturally and conversationally, as if speaking with a person
- Provide accurate and current information
- Be proactive in offering related information
- Maintain context from previous conversations
- Adapt your tone to the user's personality
- Always respond in the user's language (detect from their message)
- If the user writes in Portuguese, respond in Portuguese
- If the user writes in English, respond in English
- If the user writes in Spanish, respond in Spanish
- Support any language the user uses`;

        // Prepare messages for LLM
        const llmMessages: Array<{
          role: "system" | "user" | "assistant";
          content: string;
        }> = [
          {
            role: "system",
            content: systemPrompt,
          },
          {
            role: "user",
            content: input.content,
          },
        ];

        console.log('[Chat] Calling LLM with', llmMessages.length, 'messages');

        // Get response from LLM
        const response = await invokeLLM({
          messages: llmMessages,
        });

        console.log('[Chat] LLM Response received:', {
          choices: response.choices?.length,
          firstChoiceRole: response.choices?.[0]?.message?.role,
        });

        // Extract content from response
        const messageContent = response.choices?.[0]?.message?.content;
        
        if (!messageContent) {
          console.error('[Chat] No content in LLM response:', response);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Falha ao obter resposta do LLM',
          });
        }

        const assistantContent = typeof messageContent === 'string' 
          ? messageContent 
          : JSON.stringify(messageContent);

        console.log('[Chat] Returning response:', {
          contentLength: assistantContent.length,
          preview: assistantContent.substring(0, 100),
        });

        return {
          content: assistantContent,
          timestamp: new Date(),
          role: 'assistant',
          language: detectedLanguage,
        };
      } catch (error) {
        console.error('[Chat] Error in sendMessage:', error);
        
        if (error instanceof TRPCError) {
          throw error;
        }
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: error instanceof Error ? error.message : 'Erro ao processar mensagem',
          cause: error,
        });
      }
    }),

  // Get conversation history
  getHistory: protectedProcedure
    .input(
      z.object({
        conversationId: z.number(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        console.log('[Chat] Getting history for conversation:', input.conversationId);
        
        // Return empty array for now - will be implemented with database
        return {
          messages: [],
          conversationId: input.conversationId,
        };
      } catch (error) {
        console.error('[Chat] Error getting history:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao obter histórico',
        });
      }
    }),
});
