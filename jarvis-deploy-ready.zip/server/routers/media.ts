import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { generateImage } from "../_core/imageGeneration";
import { storagePut } from "../storage";
import {
  saveGeneratedImage,
  getGeneratedImages,
  saveStoredFile,
  getStoredFiles,
} from "../db";

export const mediaRouter = router({
  // Generate image from text prompt
  generateImage: protectedProcedure
    .input(
      z.object({
        prompt: z.string(),
        style: z.enum(["cinematic", "realistic", "artistic"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const { url: imageUrl } = await generateImage({
          prompt: input.prompt,
        });

        // Save to database with S3 reference
        const fileKey = `generated-images/${ctx.user.id}/${Date.now()}.png`;
        await saveGeneratedImage(
          ctx.user.id,
          input.prompt,
          imageUrl || "",
          fileKey,
          { style: input.style || "cinematic" }
        );

        return {
          success: true,
          imageUrl,
          prompt: input.prompt,
          createdAt: new Date(),
        };
      } catch (error) {
        console.error("[Media] Image generation error:", error);
        return {
          success: false,
          error: "Falha ao gerar imagem",
        };
      }
    }),

  // Get generated images
  getGeneratedImages: protectedProcedure.query(async ({ ctx }) => {
    return await getGeneratedImages(ctx.user.id);
  }),

  // Upload file to storage
  uploadFile: protectedProcedure
    .input(
      z.object({
        filename: z.string(),
        fileData: z.string(), // Base64 encoded
        category: z.string().optional(),
        mimeType: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Convert base64 to buffer
        const buffer = Buffer.from(input.fileData, "base64");

        // Upload to S3
        const fileKey = `user-files/${ctx.user.id}/${Date.now()}-${input.filename}`;
        const { url: fileUrl } = await storagePut(
          fileKey,
          buffer,
          input.mimeType || "application/octet-stream"
        );

        // Save metadata to database
        await saveStoredFile(
          ctx.user.id,
          input.filename,
          fileKey,
          fileUrl,
          input.mimeType,
          buffer.length,
          input.category
        );

        return {
          success: true,
          fileUrl,
          filename: input.filename,
          size: buffer.length,
          createdAt: new Date(),
        };
      } catch (error) {
        console.error("[Media] File upload error:", error);
        return {
          success: false,
          error: "Falha ao fazer upload do arquivo",
        };
      }
    }),

  // Get stored files
  getStoredFiles: protectedProcedure
    .input(z.object({ category: z.string().optional() }))
    .query(async ({ input, ctx }) => {
      return await getStoredFiles(ctx.user.id, input.category);
    }),

  // Get file download URL
  getFileUrl: protectedProcedure
    .input(z.object({ fileKey: z.string() }))
    .query(async ({ input }) => {
      // In production, you might want to generate a presigned URL
      // For now, returning the file key for reference
      return {
        fileKey: input.fileKey,
        // Presigned URL would go here
      };
    }),
});
