import { describe, it, expect } from "vitest";

describe("ElevenLabs API", () => {
  it("should validate ElevenLabs API key", async () => {
    const apiKey = process.env.ELEVENLABS_API_KEY;
    
    expect(apiKey).toBeDefined();
    expect(apiKey).toMatch(/^sk_/);
    
    // Test API connectivity
    const response = await fetch("https://api.elevenlabs.io/v1/voices", {
      headers: {
        "xi-api-key": apiKey!,
      },
    });

    expect(response.ok).toBe(true);
    const data = await response.json();
    expect(data.voices).toBeDefined();
    expect(Array.isArray(data.voices)).toBe(true);
  });
});
