import { publicProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { OpenAI } from 'openai';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// Initialize OpenAI client
const openaiClient = new OpenAI({
  apiKey: OPENAI_API_KEY,
});

export const voiceRouter = router({
  synthesize: publicProcedure
    .input(z.object({
      text: z.string().min(1),
      voiceId: z.string().optional(),
      language: z.string().optional().default('en'),
    }))
    .mutation(async ({ input }) => {
      if (!OPENAI_API_KEY) {
        throw new Error('OpenAI API key not configured');
      }
      try {
        console.log('[Voice] Synthesizing with OpenAI TTS:', {
          textLength: input.text.length,
          language: input.language,
          voice: input.voiceId || 'alloy',
        });

        // Use OpenAI's TTS with Jarvis-like voice (alloy is the most formal/professional)
        const response = await openaiClient.audio.speech.create({
          model: 'tts-1-hd',
          voice: (input.voiceId || 'alloy') as 'alloy' | 'echo' | 'fable' | 'onyx' | 'nova' | 'shimmer',
          input: input.text,
          speed: 1.0,
        });

        // Convert response to buffer
        const audioBuffer = await response.arrayBuffer();
        
        console.log('[Voice] Audio synthesized successfully:', {
          bufferSize: audioBuffer.byteLength,
        });

        // Return as base64 for easy transmission
        const base64Audio = Buffer.from(audioBuffer).toString('base64');
        return {
          audio: base64Audio,
          mimeType: 'audio/mpeg',
        };
      } catch (error) {
        console.error('[Voice] Synthesis error:', error);
        throw error;
      }
    }),

  // Get available voices
  getVoices: publicProcedure.query(async () => {
    return {
      voices: [
        {
          id: 'alloy',
          name: 'Alloy (Jarvis-like)',
          description: 'Professional, formal, masculine voice - similar to Jarvis',
          language: 'en',
        },
        {
          id: 'echo',
          name: 'Echo',
          description: 'Clear, professional voice',
          language: 'en',
        },
        {
          id: 'fable',
          name: 'Fable',
          description: 'Warm, engaging voice',
          language: 'en',
        },
        {
          id: 'onyx',
          name: 'Onyx',
          description: 'Deep, masculine voice',
          language: 'en',
        },
        {
          id: 'nova',
          name: 'Nova',
          description: 'Bright, energetic voice',
          language: 'en',
        },
        {
          id: 'shimmer',
          name: 'Shimmer',
          description: 'Smooth, pleasant voice',
          language: 'en',
        },
      ],
    };
  }),
});
