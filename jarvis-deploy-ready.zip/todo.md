# Infinito - Assistente de IA Minimalista

## Requisitos Principais
- [x] Esfera azul e branca animada (tipo ChatGPT)
- [x] Fundo simples escuro
- [x] Reconhecimento de voz (Web Speech API)
- [x] Síntese de fala com voz do Jarvis
- [x] Chat por voz apenas
- [x] Captura contínua de voz sem apertar botão
- [x] Resposta automática ao terminar de falar
- [x] Animações dinâmicas da esfera
- [ ] Disponível 24/7 mesmo com dispositivo bloqueado
- [ ] Service Worker para background
- [x] Interface minimalista - apenas a esfera

## Fase 1: Esfera Animada
- [x] Criar componente da esfera
- [x] Animações fluidas (pulso, movimento)
- [x] Indicadores de status (escutando/respondendo)
- [x] Fundo escuro simples

## Fase 2: Voz
- [x] Reconhecimento de voz automático
- [x] Síntese de fala com voz do Jarvis
- [x] Transcrição de áudio
- [x] Feedback visual de áudio
- [x] Tratamento de erros de voz
- [x] Reinicialização automática

## Fase 3: IA
- [x] Integração com LLM
- [x] Respostas contextualizadas
- [x] Logging e debug
- [x] Tratamento de erros
- [ ] Histórico de conversa

## Fase 4: Disponibilidade 24/7
- [ ] Service Worker
- [ ] Background sync
- [ ] Notificações push
- [ ] Funciona com tela apagada

## Fase 5: Testes
- [x] Testar voz
- [x] Testar IA
- [ ] Testar background
